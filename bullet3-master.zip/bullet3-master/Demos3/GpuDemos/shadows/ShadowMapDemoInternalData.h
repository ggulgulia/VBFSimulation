#ifndef SHADOW_MAP_INTERNAL_DATA_H
#define SHADOW_MAP_INTERNAL_DATA_H


struct ShadowMapDemoInternalData
{
	  class GLInstancingRenderer*   m_instancingRenderer;
	  class GLPrimitiveRenderer*	m_primitiveRenderer;

};

#endif //SHADOW_MAP_INTERNAL_DATA_H

